import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.StringTokenizer;
public class BankersAlg{
    
	private int need[][];
    private int allocate[][];
    private int max[][];
    private int available[][];
    private int nump;
    private int numr;
    private int rv[][];
    
   
     
    private void takeInput(){
     Scanner sc=new Scanner(System.in);
     System.out.print("Enter # of processes and resources : "); //rows(nump),columns(numr)
     nump=sc.nextInt();  //# of processes   
     numr=sc.nextInt();  //# of resources
     rv = new int[nump][numr];
     allocate=new int[nump][numr];   //Initialize 2d arrays for allocate, max, need, available
     max=new int[nump][numr];
     need=new int[nump][numr];
     available=new int[1][numr];
      
     System.out.println("Please enter #'s for allocation matrix: ");
     for(int i=0;i<nump;i++){
          for(int j=0;j<numr;j++){
         allocate[i][j]=sc.nextInt();  //allocation matrix
     }
     }
     
     System.out.println("Please enter #'s for max matrix: ");
     for(int i=0;i<nump;i++){
          for(int j=0;j<numr;j++){
         max[i][j]=sc.nextInt();  //max matrix
          }
    }
        System.out.println("Please enter #'s for available matrix: ");
        for(int j=0;j<numr;j++){
         available[0][j]=sc.nextInt();  //available matrix
        }
    }
     
    private int[][] findNeed(){
       for(int i=0;i<nump;i++){
         for(int j=0;j<numr;j++){  //calculating need matrix
          need[i][j]=max[i][j]-allocate[i][j];
         }
    }
       return need;
    }
  
    private boolean check(int i){
        System.out.println("Checking if Available resources meet need matrix criteria in process " + i );
       for(int j=0;j<numr;j++) {
       if(need[i][j]>available[0][j]) {
    	  System.out.println("Not enough resources for process " + i);
    	  System.out.println("Moving on to next process.....");
          return false; 
          }
       }
    return true;
    }
 
    public void cSafety(){
       takeInput();
       int x = nump *numr;
       StringBuffer str = new StringBuffer(x);
       StringBuffer bad = new StringBuffer(x);
       findNeed();
       boolean done[]=new boolean[nump];
       int j=0;
 
       while(j<nump){  //until all process allocated
       boolean allocated=false;
       for(int i=0;i<nump;i++)
        if(!done[i]){
        	bad.append("Deadlock Processes: " + i + ", ");
        	if(check(i)){  //checks to try and allocate
            for(int a=0;a<numr;a++)
            available[0][a]=available[0][a]-need[i][a]+max[i][a];
            str.append("Process: " + i + ", ");
            
            
         System.out.println("Allocated process "+i + " ,sucessfully! ");
         System.out.println("Safe Path: " + str);
         allocated=done[i]=true;
               j++;
             }
        }
          if(!allocated) break; 
          }
       if(j==nump){  //good
        System.out.println("\nSafely allocated :)");
       }
       else{
    	System.out.println("\nAvailable Resources do no meet anymore of the need matrix processes'");
        System.out.println("\nYou have hit a deadlock state!!!");
        System.out.println(bad);
    }
    }
     
    public static void main(String[] args) throws IOException {
    	BankersAlg test = new BankersAlg();
    	test.cSafety();
    }
}
    	
    
 

         
 
         